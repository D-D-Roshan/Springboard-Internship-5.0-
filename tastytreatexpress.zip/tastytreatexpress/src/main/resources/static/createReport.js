document.addEventListener("DOMContentLoaded", function () {
    const orderReportForm = document.getElementById("orderReportForm");
    const revenueReportForm = document.getElementById("revenueReportForm");

    // Create Order Report
    orderReportForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const formData = new FormData(orderReportForm);
        const data = {
            reportDate: formData.get("reportDate"),
            totalOrders: formData.get("totalOrders"),
            completedOrders: formData.get("completedOrders"),
            pendingOrders: formData.get("pendingOrders"),
            cancelledOrders: formData.get("cancelledOrders"),
            mostOrderedItem: formData.get("mostOrderedItem"),
            totalValue: formData.get("totalValue"),
        };

        fetch("/reports/createOrder", {
            method: "POST",
            headers: { "Content-Type": "multipart/form-data" },
            body: new FormData(orderReportForm),
        })
            .then((res) => res.json())
            .then((data) => alert("Order report created successfully!"))
            .catch((error) => console.error("Error:", error));
    });

    // Create Revenue Report
    revenueReportForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const formData = new FormData(revenueReportForm);
        const data = {
            reportDate: formData.get("reportDate"),
            totalOrders: formData.get("totalOrders"),
            totalRevenue: formData.get("totalRevenue"),
        };

        fetch("/reports/createRevenue", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
        })
            .then((res) => res.json())
            .then((data) => alert("Revenue report created successfully!"))
            .catch((error) => console.error("Error:", error));
    });
});
