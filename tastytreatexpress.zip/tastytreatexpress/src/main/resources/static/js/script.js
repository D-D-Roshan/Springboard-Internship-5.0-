function deleteReport(type, reportId) {
	
	
    if (!confirm("Are you sure you want to delete this report?")) {
        return;
    }

    let url = `/reports/delete${type === 'order' ? 'Order' : 'Revenue'}/${reportId}`;

    fetch(url, {
        method: "Get",
		headers: {
		            'Content-Type': 'application/json'
		         }
		
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to delete the report");
        }
        return response.text();
    })
    .then(data => {
        alert(data);  // ✅ Show success message
        document.getElementById("row-" + reportId).remove();  // ✅ Remove from UI
    })
    .catch(error => {
        alert("Error: " + error.message);
    });
}
