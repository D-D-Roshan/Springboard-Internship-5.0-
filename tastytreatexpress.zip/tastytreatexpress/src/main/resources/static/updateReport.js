// ✅ Update Order Report
async function updateOrderReport(reportId, updatedData) {
    try {
        const response = await fetch(`/reports/updateOrder/${reportId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedData),
        });
        if (!response.ok) {
            throw new Error("Failed to update order report");
        }
        return await response.json();
    } catch (error) {
        console.error("Error:", error);
    }
}

// ✅ Update Revenue Report
async function updateRevenueReport(reportId, updatedData) {
    try {
        const response = await fetch(`/reports/updateRevenue/${reportId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedData),
        });
        if (!response.ok) {
            throw new Error("Failed to update revenue report");
        }
        return await response.json();
    } catch (error) {
        console.error("Error:", error);
    }
}
document.getElementById("updateOrderForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    const reportId = document.getElementById("orderId").value;
    const updatedData = {
        totalOrders: document.getElementById("totalOrders").value,
        completedOrders: document.getElementById("completedOrders").value,
        pendingOrders: document.getElementById("pendingOrders").value,
        cancelledOrders: document.getElementById("cancelledOrders").value,
        mostOrderedItem: document.getElementById("mostOrderedItem").value
    };
    await updateOrderReport(reportId, updatedData);
});

document.getElementById("updateRevenueForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    const reportId = document.getElementById("revenueId").value;
    const updatedData = {
        totalOrders: document.getElementById("totalOrdersRevenue").value,
        totalRevenue: document.getElementById("totalRevenue").value
    };
    await updateRevenueReport(reportId, updatedData);
});
