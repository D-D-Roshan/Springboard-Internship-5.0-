document.addEventListener("DOMContentLoaded", function () {
    const reportForm = document.getElementById("reportForm");
    const startDateInput = document.getElementById("startDate");
    const endDateInput = document.getElementById("endDate");
    const reportTable = document.getElementById("reportTable");
    const reportsTable = document.getElementById("reportsTable");

    // Fetch and display all reports on page load
    function fetchReports() {
        fetch("/reports/view", { method: "GET" })
            .then((res) => res.json())
            .then((data) => {
                renderReportsTable(data);
            })
            .catch((error) => console.error("Error:", error));
    }

    // Fetch and display reports based on date range
    if (reportForm) {
        reportForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const startDate = startDateInput.value;
            const endDate = endDateInput.value;

            fetch(`/reports/view?startDate=${startDate}&endDate=${endDate}`, { method: "GET" })
                .then((res) => res.json())
                .then((data) => {
                    renderReportsTable(data);
                })
                .catch((error) => console.error("Error:", error));
        });
    }

    // Function to render reports table (used for both viewing and generating reports)
    function renderReportsTable(data) {
        const table = reportsTable || reportTable; // Use the appropriate table
        if (!table) return;

        table.innerHTML = ""; // Clear previous data

        data.forEach((report) => {
            const isOrderReport = report.hasOwnProperty("completedOrders");

            const row = `<tr>
                <td>${report.reportDate}</td>
                <td>${report.totalOrders}</td>
                <td>${isOrderReport ? report.totalValue : report.totalRevenue}</td>
                <td>${isOrderReport ? "Order Report" : "Revenue Report"}</td>
                <td>${reportsTable ? `<button onclick="deleteReport(${report.id}, '${isOrderReport ? 'order' : 'revenue'}')">Delete</button>` : ''}</td>
            </tr>`;
            table.innerHTML += row;
        });
    }

    // Delete report function (only used in manageReport.html)
    window.deleteReport = function (id, type) {
        fetch(`/reports/delete/${id}?type=${type}`, { method: "GET" })
            .then(() => {
                alert(`${type.charAt(0).toUpperCase() + type.slice(1)} report deleted successfully!`);
                fetchReports();
            })
            .catch((error) => console.error("Error:", error));
    };

    fetchReports(); // Load reports initially
});
