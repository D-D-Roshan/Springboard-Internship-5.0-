package com.tastytreat.express.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class RevenueReport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int reportId;
    private LocalDate reportDate;
    private int totalOrders;
    private double totalRevenue;
	public void setTotalRevenue(Double double1) {
		// TODO Auto-generated method stub
		
	}

	public LocalDate getReportDate() {
		return reportDate;
	}
	public void setReportDate(LocalDate reportDate) {
		this.reportDate = reportDate;
	}
	public int getTotalOrders() {
		return totalOrders;
	}
	public void setTotalOrders(int totalOrders) {
		this.totalOrders = totalOrders;
	}
	public double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}

	public int getReportId() {
		return reportId;
	}

	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	
	@Transient
	private String formattedReportId;

	public String getFormattedReportId() {
        return String.format("%03d", reportId);  // Convert reportId to "001", "002"
    }


	
}
