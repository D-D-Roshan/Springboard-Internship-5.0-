package com.tastytreat.express.controller;

import com.tastytreat.express.model.OrderReport;
import com.tastytreat.express.model.RevenueReport;
import com.tastytreat.express.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;
    
    @GetMapping("/create")
    public String createReportForm(@RequestParam(name = "type", required = false) String type) {
        if ("order".equals(type)) {
            return "createReport";  // ✅ Redirects to createOrder.html
        } else if ("revenue".equals(type)) {
            return "revenue";  // ✅ Redirects to createRevenue.html
        }
        return "create";  // ✅ Default page (if type is missing or invalid)
    }


    @PostMapping("/createOrder")
    public String createOrderReport(@ModelAttribute OrderReport report) {
        reportService.createOrderReport(report);
        return "createReport";
    }

    @PostMapping("/createRevenue")
    public String createRevenueReport(@ModelAttribute RevenueReport report) {
        reportService.createRevenueReport(report);
        return "revenue";
    }
    // ✅ View Reports Page
    @GetMapping("/view")
    public String viewReports(@RequestParam(name = "type", required = false) String type, Model model) {
        if  ("revenue".equals(type)) {
            List<RevenueReport> revenueReports = reportService.getAllRevenueReports();
//          revenueReports.forEach(report -> report.setFormattedReportId(reportService.getFormattedReportId(report.getReportId())));
          model.addAttribute("reports", revenueReports);
          model.addAttribute("reportType", "Revenue Report");
          return "gen2";  
      
        } else if ("order".equals(type)) {
            List<OrderReport> orderReports = reportService.getAllOrderReports();
//          orderReports.forEach(report -> report.setFormattedReportId(reportService.getFormattedReportId(report.getReportId())));
          model.addAttribute("reports", orderReports);
          model.addAttribute("reportType", "Order Report");
          return "gen"; 
        }
        return "generateReport";  
    }
    @GetMapping("/updateOrder/{reportId}")
    public String updateOrderForm(@PathVariable int reportId, Model model) {
        Optional<OrderReport> report = reportService.getOrderReportByReportId(reportId);
        report.ifPresent(r -> model.addAttribute("report", r));
        return report.isPresent() ? "updateOrder" : "error";
    }

    @PostMapping("/updateOrder")
    public String updateOrderReport(@ModelAttribute OrderReport report) {
        reportService.updateOrderReport(report);
        return "redirect:/reports/view?type=order";
    }

    @GetMapping("/updateRevenue/{reportId}")
    public String updateRevenueForm(@PathVariable int reportId, Model model) {
        Optional<RevenueReport> report = reportService.getRevenueReportByReportId(reportId);
        report.ifPresent(r -> model.addAttribute("report", r));
        return report.isPresent() ? "updateRevenue" : "error";
    }

    @PostMapping("/updateRevenue")
    public String updateRevenueReport(@ModelAttribute RevenueReport report) {
        reportService.updateRevenueReport(report);
        return "redirect:/reports/view?type=revenue";
    }

    @DeleteMapping("/deleteOrder/{reportId}")
    public ResponseEntity<String> deleteOrderReport(@PathVariable int reportId) {
        try {
            reportService.deleteOrderReport(reportId); 
            return ResponseEntity.ok("Order Report Deleted Successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete order report");
        }
    }

    @DeleteMapping("/deleteRevenue/{reportId}")
    public ResponseEntity<String> deleteRevenueReport(@PathVariable int reportId) {
        try {
            reportService.deleteRevenueReport(reportId); // Ensure this method actually deletes the record
            return ResponseEntity.ok("Revenue Report Deleted Successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete revenue report");
        }
    }

  


}
