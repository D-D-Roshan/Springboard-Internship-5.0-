package com.tastytreat.express.service;

import com.tastytreat.express.model.OrderReport;
import com.tastytreat.express.model.RevenueReport;
import com.tastytreat.express.repository.OrderReportRepository;
import com.tastytreat.express.repository.RevenueReportRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ReportService {

    @Autowired
    private OrderReportRepository orderReportRepository;

    @Autowired
    private RevenueReportRepository revenueReportRepository;

    // ✅ Create Order Report
    public OrderReport createOrderReport(OrderReport report) {
    	report.setReportId(generateOrderReportId());
        return orderReportRepository.save(report);
    }

    // ✅ Create Revenue Report
    public RevenueReport createRevenueReport(RevenueReport report) {
    	report.setReportId(generateRevenueReportId());
    	return revenueReportRepository.save(report);
    }
    private String formatReportId(int id) {
        return String.format("%03d", id);  // Converts 1 to "001", 10 to "010", etc.
    }
    
    private int generateOrderReportId() {
        Optional<OrderReport> lastReport = orderReportRepository.findTopByOrderByIdDesc();
        return lastReport.map(order -> order.getReportId() + 1).orElse(1);
    }
    
    private int generateRevenueReportId() {
        Optional<RevenueReport> lastReport = revenueReportRepository.findTopByOrderByIdDesc();
        return lastReport.map(revenue -> revenue.getReportId() + 1).orElse(1);
    }

	public List<OrderReport> getAllOrderReports() {
		return orderReportRepository.findAll();
	}
	public List<RevenueReport> getAllRevenueReports() {
        return revenueReportRepository.findAll();
    }
    // ✅ Get Order Report by ID
    public OrderReport getOrderReportById(Integer id) {
        return orderReportRepository.findById(id).orElse(null);
    }

    // ✅ Get Revenue Report by ID
    public RevenueReport getRevenueReportById(Integer id) {
        return revenueReportRepository.findById(id).orElse(null);
    }
    
    public Optional<OrderReport> getOrderReportByReportId(int reportId) {
        return orderReportRepository.findByReportId(reportId);
    }

    public Optional<RevenueReport> getRevenueReportByReportId(int reportId) {
        return revenueReportRepository.findByReportId(reportId);
    }

    public void updateOrderReport(OrderReport updatedReport) {
        Optional<OrderReport> existingReport = orderReportRepository.findByReportId(updatedReport.getReportId());
        existingReport.ifPresent(report -> {
            report.setReportDate(updatedReport.getReportDate());
            report.setTotalOrders(updatedReport.getTotalOrders());
            report.setCompletedOrders(updatedReport.getCompletedOrders());
            report.setPendingOrders(updatedReport.getPendingOrders());
            report.setCancelledOrders(updatedReport.getCancelledOrders());
            report.setTotalValue(updatedReport.getTotalValue());
            report.setMostOrderedItem(updatedReport.getMostOrderedItem());
            orderReportRepository.save(report);
        });
    }

    public void updateRevenueReport(RevenueReport updatedReport) {
        Optional<RevenueReport> existingReport = revenueReportRepository.findByReportId(updatedReport.getReportId());
        existingReport.ifPresent(report -> {
            report.setReportDate(updatedReport.getReportDate());
            report.setTotalOrders(updatedReport.getTotalOrders());
            report.setTotalRevenue(updatedReport.getTotalRevenue());
            revenueReportRepository.save(report);
        });
    }

	// ✅ Delete Order Report
    @Transactional
    public void deleteOrderReport(int reportId) {
        orderReportRepository.deleteById(reportId);
    }

    // ✅ Delete Revenue Report
    @Transactional
    public void deleteRevenueReport(int reportId) {
        revenueReportRepository.deleteById(reportId);
    }
   

			    
}
