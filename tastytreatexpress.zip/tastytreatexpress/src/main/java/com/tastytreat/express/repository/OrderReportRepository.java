package com.tastytreat.express.repository;

import com.tastytreat.express.model.OrderReport;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderReportRepository extends JpaRepository<OrderReport, Integer> {
	Optional<OrderReport> findTopByOrderByIdDesc();
	Optional<OrderReport> findByReportId(int reportId);
    void deleteByReportId(int reportId);

}