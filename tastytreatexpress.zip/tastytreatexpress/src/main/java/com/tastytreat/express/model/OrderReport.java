package com.tastytreat.express.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
@Table(name="order_report")
public class OrderReport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int reportId;
    private LocalDate reportDate;
    private int totalOrders;
    private int completedOrders;
    private int pendingOrders;
    private int cancelledOrders;
    private double totalValue;
    private String mostOrderedItem;
	public void setTotalOrders(Integer integer) {
		// TODO Auto-generated method stub
		
	}
	public LocalDate getReportDate() {
		return reportDate;
	}
	public void setReportDate(LocalDate reportDate) {
		this.reportDate = reportDate;
	}
	public int getTotalOrders() {
		return totalOrders;
	}
	public void setTotalOrders(int totalOrders) {
		this.totalOrders = totalOrders;
	}
	public int getCompletedOrders() {
		return completedOrders;
	}
	public void setCompletedOrders(int completedOrders) {
		this.completedOrders = completedOrders;
	}
	public int getPendingOrders() {
		return pendingOrders;
	}
	public void setPendingOrders(int pendingOrders) {
		this.pendingOrders = pendingOrders;
	}
	public int getCancelledOrders() {
		return cancelledOrders;
	}
	public void setCancelledOrders(int cancelledOrders) {
		this.cancelledOrders = cancelledOrders;
	}
	public double getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(double totalValue) {
		this.totalValue = totalValue;
	}
	public String getMostOrderedItem() {
		return mostOrderedItem;
	}
	public void setMostOrderedItem(String mostOrderedItem) {
		this.mostOrderedItem = mostOrderedItem;
	}
	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	@Transient
	private String formattedReportId;
	public String getFormattedReportId() {
	        return String.format("%03d", reportId);  // Convert reportId to "001", "002"
	    }
	
	
}
