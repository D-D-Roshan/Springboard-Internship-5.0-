package com.tastytreat.express;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TastytreatexpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(TastytreatexpressApplication.class, args);
	}

}
