package com.tastytreat.express.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HomeController {

    @GetMapping("/") // Maps the home page request
    public String home() {
        return "home"; // This should match the file name inside templates folder (index.html)
    }
}
