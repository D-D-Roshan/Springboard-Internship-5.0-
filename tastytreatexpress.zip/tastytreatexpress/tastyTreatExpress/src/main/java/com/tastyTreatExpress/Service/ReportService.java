package com.tastyTreatExpress.Service;

import com.tastyTreatExpress.DTO.ReportData;
import com.tastyTreatExpress.DTO.ReportRequest;
import com.tastyTreatExpress.Model.CustomerOrder;
import com.tastyTreatExpress.Model.Report;
import com.tastyTreatExpress.Repository.OrderRepository;
import com.tastyTreatExpress.Repository.ReportRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ReportService {
    private final OrderRepository orderRepository;
    private final ReportRepository reportRepository;

    public ReportService(OrderRepository orderRepository, ReportRepository reportRepository) {
        this.orderRepository = orderRepository;
        this.reportRepository = reportRepository;
    }

    public ReportData generateReport(ReportRequest request) {
        LocalDateTime start = request.getStartDate().atStartOfDay();
        LocalDateTime end = request.getEndDate().atTime(23, 59, 59);

        List<CustomerOrder> orders = orderRepository.findByOrderDateBetween(start, end);

        return ReportData.builder()
                .totalOrders(orders.size())
                .completed(orderRepository.countByStatusAndOrderDateBetween("COMPLETED", start, end).intValue())
                .pending(orderRepository.countByStatusAndOrderDateBetween("PENDING", start, end).intValue())
                .cancelled(orderRepository.countByStatusAndOrderDateBetween("CANCELLED", start, end).intValue())
                .totalValue(orders.stream().mapToDouble(CustomerOrder::getTotalAmount).sum())
                .mostOrderedItem(findMostOrderedItem(orders))
                .build();
    }

    public Report saveReport(ReportRequest request) {
        ReportData data = generateReport(request);

        Report report = new Report();
        report.setStartDate(request.getStartDate());
        report.setEndDate(request.getEndDate());
        report.setGeneratedAt(LocalDateTime.now());
        report.setTotalOrders(data.getTotalOrders());
        report.setCompleted(data.getCompleted());
        report.setPending(data.getPending());
        report.setCancelled(data.getCancelled());
        report.setTotalValue(data.getTotalValue());
        report.setMostOrderedItem(data.getMostOrderedItem());

        return reportRepository.save(report);
    }

    private String findMostOrderedItem(List<CustomerOrder> orders) {
        return orders.stream()
                .map(CustomerOrder::getMostOrderedItem)
                .filter(Objects::nonNull)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("No items ordered");
    }

    public Report updateReport(Long id, ReportData updateData) {
        Report report = reportRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        report.setTotalOrders(updateData.getTotalOrders());
        report.setCompleted(updateData.getCompleted());
        report.setPending(updateData.getPending());
        report.setCancelled(updateData.getCancelled());
        report.setTotalValue(updateData.getTotalValue());
        report.setMostOrderedItem(updateData.getMostOrderedItem());

        return reportRepository.save(report);
    }

    public List<Report> getAllReports(){
        return reportRepository.findAll();
    }

    public void deleteReport(Long id) {
        reportRepository.deleteById(id);
    }

    public void deleteAllReports() {
        reportRepository.deleteAll();
    }
}