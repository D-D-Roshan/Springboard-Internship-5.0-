package com.tastyTreatExpress.Controller;


import com.tastyTreatExpress.DTO.ReportData;
import com.tastyTreatExpress.DTO.ReportRequest;
import com.tastyTreatExpress.Model.Report;
import com.tastyTreatExpress.Service.ReportService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService ;

    @PostMapping("/generate")
    public ResponseEntity<ReportData> generateReport(@RequestBody ReportRequest request) {
        return ResponseEntity.ok(reportService.generateReport(request));
    }

    @PostMapping("/save")
    public ResponseEntity<Report> createReport(@RequestBody ReportRequest request) {
        return ResponseEntity.ok(reportService.saveReport(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Report> updateReport(@PathVariable Long id, @RequestBody ReportData updateData) {
        return ResponseEntity.ok(reportService.updateReport(id, updateData));
    }

    @GetMapping
    public ResponseEntity<List<Report>> getAllReports(){
        List<Report> reports = reportService.getAllReports();
        return ResponseEntity.ok(reports);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReport(@PathVariable Long id) {
        reportService.deleteReport(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllReports() {
        reportService.deleteAllReports();
        return ResponseEntity.noContent().build();
    }
}