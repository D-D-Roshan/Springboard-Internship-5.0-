package com.tastyTreatExpress.Model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class MenuItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long menuItemId; // menuItemId

    private Long restaurantId; // restaurantId
    private String name; // name of the menu item
    private String description; // description of the menu item
    private Double currentPrice; // current price of the menu item
    private String category; // category of the menu item
}
