package com.tastyTreatExpress.Repository;


import com.tastyTreatExpress.Model.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<CustomerOrder, Long> {
    List<CustomerOrder> findByOrderDateBetween(LocalDateTime start, LocalDateTime end);
    Long countByStatusAndOrderDateBetween(String status, LocalDateTime start, LocalDateTime end);
    List<CustomerOrder> findByUserId(Long userId);
}