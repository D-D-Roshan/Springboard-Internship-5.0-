package com.tastyTreatExpress.Service;


import com.tastyTreatExpress.Model.MenuItem;
import com.tastyTreatExpress.Repository.MenuItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MenuItemService {
    @Autowired
    private MenuItemRepository menuItemRepository;

    // 1. Get list of menu items by restaurant ID
    public List<MenuItem> getMenuItemsByRestaurantId(Long restaurantId) {
        return menuItemRepository.findByRestaurantId(restaurantId);
    }

    // 2. Get menu item by ID
    public Optional<MenuItem> getMenuItemById(Long menuItemId) {
        return menuItemRepository.findById(menuItemId);
    }

    // 3. Update menu item by ID
    public MenuItem updateMenuItem(Long menuItemId, MenuItem updatedMenuItem) {
        updatedMenuItem.setMenuItemId(menuItemId);
        return menuItemRepository.save(updatedMenuItem);
    }

    // 4. Delete menu item by ID
    public void deleteMenuItem(Long menuItemId) {
        menuItemRepository.deleteById(menuItemId);
    }

    // 5. Delete all menu items
    public void deleteAllMenuItems() {
        menuItemRepository.deleteAll();
    }
}
