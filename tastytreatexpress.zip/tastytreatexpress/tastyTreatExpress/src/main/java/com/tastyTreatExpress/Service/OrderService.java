package com.tastyTreatExpress.Service;
import com.tastyTreatExpress.DTO.OrderResponse;
import com.tastyTreatExpress.Model.CustomerOrder;
import com.tastyTreatExpress.Repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<OrderResponse> getOrdersByUserId(Long userId) {
        List<CustomerOrder> orders = orderRepository.findByUserId(userId);
        List<OrderResponse> response = orders.stream()
                .map(order -> new OrderResponse(
                        order.getId(),
                        order.getOrderName(),
                        order.getTotalAmount(),
                        order.getOrderDate(),
                        order.getStatus(),
                        order.getRestaurant().getName() // Fetching restaurant name

                ))
                .toList();
        return response;
    }
}