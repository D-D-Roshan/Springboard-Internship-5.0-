package com.tastyTreatExpress.Service;


import com.tastyTreatExpress.Model.Restaurant;
import com.tastyTreatExpress.Repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;

    @Autowired
    public RestaurantService(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    // Get all restaurants
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

//    // Get a restaurant by ID (if needed in the future)
//    public Restaurant getRestaurantById(Long id) {
//        return restaurantRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Restaurant not found with id: " + id));
//    }
}
