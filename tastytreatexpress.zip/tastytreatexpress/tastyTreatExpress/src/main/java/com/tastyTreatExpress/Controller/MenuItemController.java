package com.tastyTreatExpress.Controller;

import com.tastyTreatExpress.Model.MenuItem;
import com.tastyTreatExpress.Service.MenuItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/menu-items")
public class MenuItemController {
    @Autowired
    private MenuItemService menuItemService;

    // 1. Get list of menu items by restaurant ID
    @GetMapping("/restaurant/{restaurantId}")
    public ResponseEntity<List<MenuItem>> getMenuItemsByRestaurantId(@PathVariable Long restaurantId) {
        List<MenuItem> menuItems = menuItemService.getMenuItemsByRestaurantId(restaurantId);
        return ResponseEntity.ok(menuItems);
    }

    // 2. Get menu item by ID
    @GetMapping("/{menuItemId}")
    public ResponseEntity<MenuItem> getMenuItemById(@PathVariable Long menuItemId) {
        Optional<MenuItem> menuItem = menuItemService.getMenuItemById(menuItemId);
        return menuItem.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 3. Update menu item by ID
    @PutMapping("/{menuItemId}")
    public ResponseEntity<MenuItem> updateMenuItem(@PathVariable Long menuItemId, @RequestBody MenuItem updatedMenuItem) {
        MenuItem menuItem = menuItemService.updateMenuItem(menuItemId, updatedMenuItem);
        return ResponseEntity.ok(menuItem);
    }

    // 4. Delete menu item by ID
    @DeleteMapping("/{menuItemId}")
    public ResponseEntity<Void> deleteMenuItem(@PathVariable Long menuItemId) {
        menuItemService.deleteMenuItem(menuItemId);
        return ResponseEntity.noContent().build();
    }

    // 5. Delete all menu items
    @DeleteMapping
    public ResponseEntity<Void> deleteAllMenuItems() {
        menuItemService.deleteAllMenuItems();
        return ResponseEntity.noContent().build();
    }
}