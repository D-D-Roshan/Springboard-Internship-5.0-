package com.tastyTreatExpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TastyTreatExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
